__author__ = 'root'

from enum import Enum


class LocalisationFr(Enum):
    WINDOW_PROGRAM_NAME = "Files Finder"

    TEXT_BROWSE = "Parcourir"

    PANEL_ANALYSE = "Analyse"
    PANEL_ANALYSE_CONTENT = "Analyser le répertoire"
    PANEL_ANALYSE_BUTTON = "Analyser"

    PANEL_ABOUT = "A propos"
    PANEL_ABOUT_CONTENT = "Files Finder a été créé par Florian VAUTARD. Il est possible de l'utiliser et de le modifier mais en\n ancun cas de" \
                          " de le vendre sans son autorisation."

    MESSAGE_EMPTY_NAME = "Il est nécessaire de saisir un nom du répertoire valide"
    MESSAGE_SUCCESS = "Félicitation, le répertoire a bien été analysé."

    MESSAGE_TYPE_INFORMATION = "Information"
    MESSAGE_TYPE_WARNING = "Attention"
    MESSAGE_TYPE_ERROR = "Erreur"

    LOG_ERROR = "Fucking error"