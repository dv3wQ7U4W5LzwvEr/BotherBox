__author__ = 'root'

from tkinter import *
from tkinter import messagebox
from tkinter.filedialog import askdirectory
from tkinter.messagebox import showerror
import datetime

from LocalisationFr import LocalisationFr
from AnalyzeMotor import AnalyzeMotor

from exception.ExceptionMissingDirectory import ExceptionMissingDirectory
from exception.ExceptionPermissionDenied import ExceptionPermissionDenied


class Interface(Tk):
    def __init__(self):
        Tk.__init__(self)
        self.title(LocalisationFr.WINDOW_PROGRAM_NAME.value)
        self.panel_analyze = self.panel_analyze()
        self.panel_about = self.panel_about()
        self.menu()
        self.resizable(width=FALSE, height=FALSE)
        self.show_panel_analyze()
        print(datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S") + " Program start")

    def menu(self):
        menubar = Menu(self, tearoff=0)
        menubar.add_command(label=LocalisationFr.PANEL_ANALYSE.value, command=self.show_panel_analyze)
        menubar.add_command(label=LocalisationFr.PANEL_ABOUT.value, command=self.show_panel_about)

        self.config(menu=menubar)

    def show_panel_analyze(self):
        self.panel_analyze.pack()
        self.panel_about.pack_forget()

    def show_panel_about(self):
        self.panel_analyze.pack_forget()
        self.panel_about.pack()

    def panel_analyze(self):
        panel_analyze = PanedWindow(self, orient=HORIZONTAL)
        p_analyze_content = PanedWindow(panel_analyze, orient=HORIZONTAL)
        p_analyze_content.add(Label(p_analyze_content, text=LocalisationFr.PANEL_ANALYSE_CONTENT.value))
        self.archive_input_file_path = Entry(p_analyze_content, textvariable=StringVar(), width=50)
        p_analyze_content.pack(side=TOP, fill=BOTH, padx=5)

        self.analyze_input_directory_path = Entry(p_analyze_content, textvariable=StringVar(), width=50)
        p_analyze_content.add(self.analyze_input_directory_path)
        p_analyze_content.add(
            Button(p_analyze_content, text=LocalisationFr.TEXT_BROWSE.value, command=self.load_directory))
        p_analyze_content.pack(side=TOP, fill=BOTH, padx=5)

        Button(panel_analyze, text=LocalisationFr.PANEL_ANALYSE_BUTTON.value, command=self.launch_analyze).pack(
            padx=10, pady=10)

        return panel_analyze

    def panel_about(self):
        panel_about = PanedWindow(self, orient=HORIZONTAL)
        p_file_name = PanedWindow(panel_about, orient=HORIZONTAL)
        p_file_name.add(Label(p_file_name, text=LocalisationFr.PANEL_ABOUT_CONTENT.value))
        p_file_name.pack(side=TOP, fill=BOTH, padx=5)

        return panel_about

    def load_directory(self):
        directory_path = askdirectory()
        if directory_path:
            try:
                self.analyze_input_directory_path.delete(0, 10000)
                self.analyze_input_directory_path.insert(0, directory_path)
            except IOError:
                showerror("Open Source File", "Failed to read file\n'%s'" % directory_path)


    def launch_analyze(self):
        directory_path = self.analyze_input_directory_path.get()
        try:
            print(datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S") + " Analyze begin of " + directory_path)
            AnalyzeMotor.analyze_from_directory(directory_path)
            print(datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S") + " Analyze completed of " + directory_path)
            messagebox.showinfo(LocalisationFr.MESSAGE_TYPE_INFORMATION.value, LocalisationFr.MESSAGE_SUCCESS.value)
        except ValueError:
            print(datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S") + LocalisationFr.LOG_ERROR.value)
            messagebox.showerror(LocalisationFr.MESSAGE_TYPE_ERROR.value, LocalisationFr.LOG_ERROR.value)
        except ExceptionMissingDirectory:
            print(datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S") + " " + str(ExceptionMissingDirectory(directory_path)))
            messagebox.showerror(LocalisationFr.MESSAGE_TYPE_ERROR.value, ExceptionMissingDirectory(directory_path))
        except ExceptionPermissionDenied:
            print(datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S") + " " +  str(ExceptionPermissionDenied(directory_path)))
            messagebox.showerror(LocalisationFr.MESSAGE_TYPE_ERROR.value, ExceptionPermissionDenied(directory_path))