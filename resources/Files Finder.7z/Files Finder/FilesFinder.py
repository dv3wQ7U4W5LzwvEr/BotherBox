__author__ = 'florian'

from Interface import Interface

i = Interface()
i.mainloop()
